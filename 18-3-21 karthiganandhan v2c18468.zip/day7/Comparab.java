import java.util.ArrayList;
import java.util.Collections;  
class Student1 implements Comparable<Student1>{  
int rollno;  
String name;  
int age;  
Student1(int rollno,String name,int age){  
this.rollno=rollno;  
this.name=name;  
this.age=age;  
}  
public int compareTo(Student1 st){  
if(age==st.age)  
return 0;  
else if(age>st.age)  
return 1;  
else  
return -1;  
}  
}  

public class Comparab{  
public static void main(String args[]){  
ArrayList<Student1> obj=new ArrayList<Student1>();  
obj.add(new Student1(1,"nandha",25));  
obj.add(new Student1(5,"surya",24));  
obj.add(new Student1(01,"siva",21));  
  
Collections.sort(obj);  
for(Student1 var:obj){  
System.out.println(var.rollno+" "+var.name+" "+var.age);  
}  
}  
}  