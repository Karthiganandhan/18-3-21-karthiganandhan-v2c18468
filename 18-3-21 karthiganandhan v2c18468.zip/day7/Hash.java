class Hash{  
    public static void main(String[] args)
    {  
        String a = "nandha";  
        String b = "nandha";
        Integer a1=5;
        Integer a2=6;
        
  
        if(a.equals(b))
        {
        	
            System.out.println("a & b are equal str :" + " "+ a.hashCode() + " & " + b.hashCode());  
          
        }  
        if(a1.equals(a2))
        {
        	
            System.out.println("a & b are equal :" + " "+ a.hashCode() + " & " + b.hashCode());  
          
        }  
       
    }  
}  